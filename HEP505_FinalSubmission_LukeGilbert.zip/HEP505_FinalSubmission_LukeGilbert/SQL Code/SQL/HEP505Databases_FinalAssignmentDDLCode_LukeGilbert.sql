------------------------------------

-- HEP505 DATABASES FINAL ASSIGNMENT - DDL CODE FOR COMPANY DATABASE
-- BY LUKE GILBERT
-- 22/04/2024

------------------------------------


-- ONLY RUN THIS DDL CODE BLOCK AFTER INITIALISATION OF THE DATABASE TO CLEAR ALL TABLES. USE WITH CAUTION. 

/* -------------------------------------------------------------------

-- Initialise by dropping tables and fks from the previous run of the script. 

DROP TABLE Employees CASCADE CONSTRAINTS;
DROP TABLE Managers CASCADE CONSTRAINTS;
DROP TABLE Customers CASCADE CONSTRAINTS;
DROP TABLE Dependents CASCADE CONSTRAINTS;
DROP TABLE Projects CASCADE CONSTRAINTS;
DROP TABLE Departments CASCADE CONSTRAINTS;
DROP TABLE Locations CASCADE CONSTRAINTS;
DROP TABLE ProjectParticipation CASCADE CONSTRAINTS;
DROP TABLE SalesLog CASCADE CONSTRAINTS;
DROP TABLE Products CASCADE CONSTRAINTS;
DROP TABLE StockItem CASCADE CONSTRAINTS;
DROP TABLE Warehouses CASCADE CONSTRAINTS;

-------------------------------------------------------------------
*/


-- Create Employees Table with Columns from Relational Model
CREATE TABLE Employees (
    employeeNo NUMBER PRIMARY KEY,
    firstName VARCHAR2(50) CONSTRAINT EMP_FN_NN NOT NULL ENABLE,
    lastName VARCHAR2(50) CONSTRAINT EMP_LN_NN NOT NULL ENABLE,
    NI_Number VARCHAR2(9) CONSTRAINT EMP_NI_NN NOT NULL ENABLE UNIQUE,
    address VARCHAR2(200) CONSTRAINT EMP_ADD_NN NOT NULL ENABLE,
    salary NUMBER,
    DoB DATE,
    email VARCHAR2(100),
    phoneNo VARCHAR2(25),
    startDate DATE CONSTRAINT EMP_START_NN NOT NULL ENABLE,
    endDate DATE,
    reportsTo NUMBER,
    departmentID NUMBER,
    CONSTRAINT VALID_SALARY CHECK (salary > 0) ENABLE, -- Valid salaries should be greater than zero
    CONSTRAINT EMP_EMAIL_UNQ UNIQUE (email) ENABLE, -- Every employee should have a unique email
    CONSTRAINT EMP_TENURE CHECK (startDate < endDate) ENABLE, -- Employee cannot have a end date which precedes their end date
    CONSTRAINT EMP_MAN CHECK (employeeNo <> reportsTo)
);

-- Virtual columns added with UK format of dates in table
ALTER TABLE Employees ADD (uk_DoB VARCHAR2(36) GENERATED ALWAYS AS (to_char(DoB, 'DD/MM/YYYY')) VIRTUAL,
                           uk_StartDate VARCHAR2(36) GENERATED ALWAYS AS (to_char(startDate, 'DD/MM/YYYY')) VIRTUAL,
                           uk_EndDate VARCHAR2(36) GENERATED ALWAYS AS (to_char(endDate, 'DD/MM/YYYY')) VIRTUAL);

-- Create Managers Table with Columns from Relational Model
CREATE TABLE Managers (
    managerID NUMBER PRIMARY KEY,
    employeeNo NUMBER CONSTRAINT MAN_EMP_NN NOT NULL ENABLE,
    departmentID NUMBER CONSTRAINT MAN_DPT_NN NOT NULL ENABLE,
    managerStart DATE CONSTRAINT MAN_START_NN NOT NULL ENABLE,
    managerEnd DATE,
    CONSTRAINT MAN_TENURE CHECK (managerStart < managerEnd) ENABLE -- Manager cannot have a end date which precedes their end date
);

-- Virtual columns added with UK format of dates in table
ALTER TABLE Managers ADD (uk_managerStart VARCHAR2(36) GENERATED ALWAYS AS (to_char(managerStart, 'DD/MM/YYYY')) VIRTUAL,
                          uk_managerEnd VARCHAR2(36) GENERATED ALWAYS AS (to_char(managerEnd, 'DD/MM/YYYY')) VIRTUAL);

-- Create Customers Table with Columns from Relational Model
CREATE TABLE Customers (
    customerNo NUMBER PRIMARY KEY,
    firstName VARCHAR2(50) CONSTRAINT CUST_FN_NN NOT NULL ENABLE,
    lastName VARCHAR2(50) CONSTRAINT CUST_LN_NN NOT NULL ENABLE,
    employeeNo NUMBER
);
-- Create Dependents Table with Columns from Relational Model
CREATE TABLE Dependents (
    employeeNo NUMBER,
    firstName VARCHAR2(50) CONSTRAINT DEP_FN_NN NOT NULL ENABLE,
    lastName VARCHAR2(50) CONSTRAINT DEP_LN_NN NOT NULL ENABLE,
    DoB DATE CONSTRAINT DEP_DOB_NN NOT NULL ENABLE,
    relationship VARCHAR (15) CONSTRAINT DEP_REL_NN NOT NULL ENABLE,
    CONSTRAINT DEP_PK PRIMARY KEY (employeeNo, firstName)
);

-- Virtual columns added with UK format of dates in table
ALTER TABLE Dependents ADD uk_DoB VARCHAR2(36) GENERATED ALWAYS AS (to_char(DoB, 'DD/MM/YYYY')) VIRTUAL;

-- Create Projects Table with Columns from Relational Model
CREATE TABLE Projects (
    projectNo NUMBER PRIMARY KEY,
    projectName VARCHAR2(50) CONSTRAINT PROJ_NM_NN NOT NULL ENABLE,
    budget NUMBER,
    dateStarted DATE CONSTRAINT PROJ_DS_NN NOT NULL ENABLE 
);

-- Create Departments Table with Columns from Relational Model
CREATE TABLE Departments (
    departmentID NUMBER PRIMARY KEY,
    departmentName VARCHAR2(50) CONSTRAINT DPT_NM_NN NOT NULL ENABLE
);

-- Create Locations Table with Columns from Relational Model
CREATE TABLE Locations (
    locationID NUMBER PRIMARY KEY,
    locationName VARCHAR(50) CONSTRAINT LOC_NM_NN NOT NULL ENABLE,
    address VARCHAR2(200) CONSTRAINT LOC_ADD_NN NOT NULL ENABLE,
    departmentID NUMBER CONSTRAINT LOC_DEP_NN NOT NULL ENABLE
);

-- Create Products Table with Columns from Relational Model
CREATE TABLE Products (
    productID NUMBER PRIMARY KEY,
    productName VARCHAR2(500) CONSTRAINT PROD_NM_NN NOT NULL ENABLE,
    price NUMBER CONSTRAINT PROD_PRC_NN NOT NULL ENABLE
);

-- Create Warehouses Table with Columns from Relational Model
CREATE TABLE Warehouses (
    warehouseID NUMBER PRIMARY KEY,
    warehouseName VARCHAR2(50) CONSTRAINT WAR_NM_NN NOT NULL ENABLE,
    address VARCHAR2(200) CONSTRAINT WAR_ADD_NN NOT NULL ENABLE
);

-- Create ProjectParticipation Table with Columns from Relational Model (Bridging Table)
CREATE TABLE ProjectParticipation (
    projectNo NUMBER,
    employeeNo NUMBER,
    hoursWorked NUMBER CONSTRAINT PP_HW_NN NOT NULL ENABLE,
    CONSTRAINT PP_PK PRIMARY KEY (projectNo, employeeNo)
);

-- Create SalesLog Table with Columns from Relational Model (Bridging Table)
CREATE TABLE SalesLog (
    customerNo NUMBER,
    productID NUMBER,
    transactionTimestamp TIMESTAMP CONSTRAINT SL_TD_NN NOT NULL ENABLE,
    CONSTRAINT SL_PK PRIMARY KEY (customerNo, transactionTimestamp)
);

-- Create StockItem Table with Columns from Relational Model (Bridging Table)
CREATE TABLE StockItem (
    warehouseID NUMBER,
    productID NUMBER,
    stock NUMBER CONSTRAINT SI_STK_NN NOT NULL ENABLE,
    CONSTRAINT SI_PK PRIMARY KEY (warehouseID, productID)
);

-- Add Foreign Keys to Tables

ALTER TABLE Employees ADD (
    CONSTRAINT EMP_MNG_FK FOREIGN KEY (reportsTo) REFERENCES Employees(employeeNo) ON DELETE CASCADE,
    CONSTRAINT EMP_DPT_FK FOREIGN KEY (departmentID) REFERENCES Departments(departmentID) ON DELETE CASCADE
);

ALTER TABLE Managers ADD (
    CONSTRAINT MAN_EMP_FK FOREIGN KEY (employeeNo) REFERENCES Employees(employeeNo) ON DELETE CASCADE,
    CONSTRAINT MAN_DPT_FK FOREIGN KEY (departmentID) REFERENCES Departments(departmentID) ON DELETE CASCADE
);

ALTER TABLE Dependents ADD (
    CONSTRAINT DEP_EMP_FK FOREIGN KEY (employeeNo) REFERENCES Employees(employeeNo) ON DELETE CASCADE  
);

ALTER TABLE Locations ADD (
    CONSTRAINT LOC_DPT_FK FOREIGN KEY (departmentID) REFERENCES Departments(departmentID) ON DELETE CASCADE  
);

ALTER TABLE Customers ADD (
    CONSTRAINT CUST_EMP_FK FOREIGN KEY (employeeNo) REFERENCES Employees(employeeNo) ON DELETE CASCADE
);

ALTER TABLE ProjectParticipation ADD (
    CONSTRAINT PP_PROJ_FK FOREIGN KEY (projectNo) REFERENCES Projects(projectNo) ON DELETE CASCADE,
    CONSTRAINT PP_EMP_FK FOREIGN KEY (employeeNo) REFERENCES Employees(employeeNo) ON DELETE CASCADE
);

ALTER TABLE SalesLog ADD (
    CONSTRAINT SL_CUST_FK FOREIGN KEY (customerNo) REFERENCES Customers(customerNo) ON DELETE CASCADE,
    CONSTRAINT SL_PROD_FK FOREIGN KEY (productID) REFERENCES Products(productID) ON DELETE CASCADE
);

ALTER TABLE StockItem ADD (
    CONSTRAINT SI_WAR_FK FOREIGN KEY (warehouseID) REFERENCES Warehouses(warehouseID) ON DELETE CASCADE,
    CONSTRAINT SI_PROD_FK FOREIGN KEY (productID) REFERENCES Products(productID) ON DELETE CASCADE
);