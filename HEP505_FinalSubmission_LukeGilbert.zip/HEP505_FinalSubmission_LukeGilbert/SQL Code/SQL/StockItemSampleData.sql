DROP TABLE StockItemTemp;

CREATE TABLE StockItemTemp (warehouseID NUMBER, productID NUMBER, stock NUMBER);

INSERT INTO StockItemTemp (warehouseID, productID, stock)
    SELECT
    round(dbms_random.value(1,5),0),
    round(dbms_random.value(1,300),0),
    round(dbms_random.value(1,1000),0)
    FROM DUAL CONNECT BY level <= 1000;


DELETE from StockItemTemp WHERE rowid not in (SELECT MAX(rowid) FROM StockItemTemp GROUP BY warehouseID, productID);