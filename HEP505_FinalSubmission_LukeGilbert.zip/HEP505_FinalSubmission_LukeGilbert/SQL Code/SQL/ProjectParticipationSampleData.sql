DROP TABLE ProjectTemp;

CREATE TABLE ProjectTemp (projectNo NUMBER, employeeNo NUMBER, hoursWorked NUMBER);

INSERT INTO ProjectTemp (projectNo, employeeNo, hoursWorked)
    SELECT
    round(dbms_random.value(1,6),0),
    round(dbms_random.value(1,100),0),
    round(dbms_random.value(1,1000),0)
    FROM DUAL CONNECT BY level <= 500;


DELETE from ProjectTemp WHERE rowid not in (SELECT MAX(rowid) FROM ProjectTemp GROUP BY projectNo, employeeNo);