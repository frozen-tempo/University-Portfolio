------------------------------------

-- HEP505 DATABASES FINAL ASSIGNMENT - DML CODE FOR COMPANY DATABASE
-- BY LUKE GILBERT
-- 22/04/2024

------------------------------------

DELETE FROM Employees;
DELETE FROM Customers;
DELETE FROM Dependents;
DELETE FROM Projects;
DELETE FROM Departments;
DELETE FROM Locations;
DELETE FROM ProjectParticipation;
DELETE FROM Products;
DELETE FROM SalesLog;
DELETE FROM Warehouses;
DELETE FROM StockItem;
DROP SEQUENCE CUST_NO_SEQ;
DROP SEQUENCE MAN_ID_SEQ;

CREATE SEQUENCE CUST_NO_SEQ START WITH 1;
CREATE SEQUENCE MAN_ID_SEQ START WITH 1;

-- Inserts data into the employees table from the imported 'people' table as well as some other randomly generated data
INSERT INTO Employees (employeeNo, firstName, lastName, NI_Number, address, salary, DoB, email, startDate, phoneNo)
SELECT 
    ID_1,
    first_name,
    last_name,
    generateNINumber, -- PL/SQL Function used to generate a random NI Number for each employee
    getRandomAddress, -- PL/SQL Function which selects a random address from the imported addresses table
    FLOOR(dbms_random.value(25000, 75000) / 250) * 250,
    to_date('12/31/2006') - dbms_random.value(1,10000), -- Assumes that all employees are at least 18 years old
    first_name || '.' || last_name || '@email.com',
    current_date - dbms_random.value(1,1000), -- Random start date for an employee before current day
    generatePhoneNumber -- Generates random UK Phone Number
FROM People
WHERE ID_1 <= 100;

-- Updates some rows to show randomly generated leaving dates which must be after the employee start date
UPDATE Employees
SET endDate = 
    CASE
        WHEN mod(employeeNo, 20) = 0 THEN startDate + (dbms_random.value(0,current_date - startDate)+1)
        ELSE endDate
    END;

-- Inserts data into the customers table from the imported 'people' table as well as some other randomly generated data
INSERT INTO Customers (customerNo, firstName, lastName, employeeNo)
SELECT 
    CUST_NO_SEQ.NEXTVAL,
    first_name,
    last_name,
    round(dbms_random.value(1,100),0) -- Randomly assigns an customer to an employee
FROM People
WHERE ID_1 > 100 AND ID_1 <= 300;

-- Inserts data into the customers table from the imported 'people' table as well as some other randomly generated data
INSERT INTO Dependents (employeeNo, firstName, lastName, DoB, relationship)
SELECT 
    round(dbms_random.value(1,100),0), -- Randomly assigns a dependent to employee
    first_name,
    last_name,
    current_date - dbms_random.value(1,20000),
    'Other' -- This column is not nullable so needs a default value for initial insert, function cannot be used on data which is not yet inserted
FROM People
WHERE ID_1 > 300 AND ID_1 <= 400;

-- After initial insert use the table values in the function to generate a random relationship between dependent and employee based on their age difference
UPDATE Dependents
SET relationship = getRandomRelationship((SELECT DoB FROM Employees WHERE Employees.employeeNo = Dependents.employeeNo), Dependents.DoB);

-- Inserts data for the projects table
INSERT ALL 
    INTO Projects (projectNo, projectName, budget, dateStarted) VALUES (1, 'Project_1', FLOOR(dbms_random.value(10000, 1000000) / 250) * 250, current_date - dbms_random.value(1,2000))
    INTO Projects (projectNo, projectName, budget, dateStarted) VALUES (2, 'Project_2', FLOOR(dbms_random.value(10000, 1000000) / 250) * 250, current_date - dbms_random.value(1,2000))
    INTO Projects (projectNo, projectName, budget, dateStarted) VALUES (3, 'Project_3', FLOOR(dbms_random.value(10000, 1000000) / 250) * 250, current_date - dbms_random.value(1,2000))
    INTO Projects (projectNo, projectName, budget, dateStarted) VALUES (4, 'Project_4', FLOOR(dbms_random.value(10000, 1000000) / 250) * 250, current_date - dbms_random.value(1,2000))
    INTO Projects (projectNo, projectName, budget, dateStarted) VALUES (5, 'Project_5', FLOOR(dbms_random.value(10000, 1000000) / 250) * 250, current_date - dbms_random.value(1,2000))
    INTO Projects (projectNo, projectName, budget, dateStarted) VALUES (6, 'Project_6', FLOOR(dbms_random.value(10000, 1000000) / 250) * 250, current_date - dbms_random.value(1,2000))
SELECT * FROM DUAL;

-- Inserts data for the departments table
INSERT ALL 
    INTO Departments (departmentID, departmentName) VALUES (1, 'Engineering')
    INTO Departments (departmentID, departmentName) VALUES (2, 'Sales')
    INTO Departments (departmentID, departmentName) VALUES (3, 'Admin')
    INTO Departments (departmentID, departmentName) VALUES (4, 'Operations')
    INTO Departments (departmentID, departmentName) VALUES (5, 'Recruitment')
SELECT * FROM DUAL;

-- Updates the employees table giving each employee a randomly assigned department
UPDATE Employees
SET departmentID = round(dbms_random.value(1,5),0);

-- Inserts data for the locations table
INSERT ALL 
    INTO Locations (locationID, locationName, address, departmentID) VALUES (1, 'Location_1', getRandomAddress, 1)
    INTO Locations (locationID, locationName, address, departmentID) VALUES (2, 'Location_2', getRandomAddress, 3)
    INTO Locations (locationID, locationName, address, departmentID) VALUES (3, 'Location_3', getRandomAddress, 4)
    INTO Locations (locationID, locationName, address, departmentID) VALUES (4, 'Location_4', getRandomAddress, 2)
    INTO Locations (locationID, locationName, address, departmentID) VALUES (5, 'Location_5', getRandomAddress, 5)
SELECT * FROM DUAL;

-- Inserts data for the ProjectTemp table which is a generated table of data which has had all duplicate primary key occurances removed
INSERT INTO ProjectParticipation (projectNo, employeeNo, hoursWorked)
SELECT
    projectNo,
    employeeNo,
    hoursWorked
    FROM ProjectTemp;

-- Inserts data for the products table from the imported 'Sample_Products' table
INSERT INTO Products (productID, productName, price)
    SELECT
        ID,
        productName,
        price
    FROM Sample_Products WHERE ID <= 300;

-- Inserts data for the sales log table, note here that it is possible for a customer to purchase the same product but at a different time since the product is not a primary key or unique constraint
INSERT INTO SalesLog (customerNo, productID, transactionTimeStamp)
    SELECT 
        round(dbms_random.value(1,200),0),
        round(dbms_random.value(1,300),0),
        current_timestamp - dbms_random.value(1,1000) 
    FROM DUAL CONNECT BY level <= 5000;

-- Inserts data for the warehouses table
INSERT ALL 
    INTO Warehouses (warehouseID, warehouseName, address) VALUES (1, 'Warehouse_1', getRandomAddress)
    INTO Warehouses (warehouseID, warehouseName, address) VALUES (2, 'Warehouse_2', getRandomAddress)
    INTO Warehouses (warehouseID, warehouseName, address) VALUES (3, 'Warehouse_3', getRandomAddress)
    INTO Warehouses (warehouseID, warehouseName, address) VALUES (4, 'Warehouse_4', getRandomAddress)
    INTO Warehouses (warehouseID, warehouseName, address) VALUES (5, 'Warehouse_5', getRandomAddress)
SELECT * FROM DUAL;

-- Inserts data for the StockItemTemp table which is a generated table of data which has had all duplicate primary key occurances removed
INSERT INTO StockItem (warehouseID, productID, stock)
    SELECT
        warehouseID,
        productID,
        stock
    FROM StockItemTemp;

-- Inserts data for the Managers table ensuring the manager for a department belongs to that department also
INSERT INTO Managers (managerID, employeeNo, departmentID, managerStart) 
VALUES  (MAN_ID_SEQ.NEXTVAL, 
        (SELECT employeeNo FROM Employees WHERE departmentID = 1 ORDER BY firstName FETCH FIRST 1 ROW ONLY),
        (SELECT departmentID FROM Employees WHERE departmentID = 1 ORDER BY firstName FETCH FIRST 1 ROW ONLY),
        (SELECT startDate FROM Employees WHERE departmentID = 1 ORDER BY firstName FETCH FIRST 1 ROW ONLY) 
        + dbms_random.value(0,current_Date-(SELECT startDate FROM Employees WHERE departmentID = 1 ORDER BY firstName FETCH FIRST 1 ROW ONLY)));

INSERT INTO Managers (managerID, employeeNo, departmentID, managerStart) 
VALUES  (MAN_ID_SEQ.NEXTVAL, 
        (SELECT employeeNo FROM Employees WHERE departmentID = 2 ORDER BY firstName FETCH FIRST 1 ROW ONLY),
        (SELECT departmentID FROM Employees WHERE departmentID = 2 ORDER BY firstName FETCH FIRST 1 ROW ONLY),
        (SELECT startDate FROM Employees WHERE departmentID = 2 ORDER BY firstName FETCH FIRST 1 ROW ONLY) 
        + dbms_random.value(0,current_Date-(SELECT startDate FROM Employees WHERE departmentID = 2 ORDER BY firstName FETCH FIRST 1 ROW ONLY)));

INSERT INTO Managers (managerID, employeeNo, departmentID, managerStart) 
VALUES  (MAN_ID_SEQ.NEXTVAL, 
        (SELECT employeeNo FROM Employees WHERE departmentID = 3 ORDER BY firstName FETCH FIRST 1 ROW ONLY),
        (SELECT departmentID FROM Employees WHERE departmentID = 3 ORDER BY firstName FETCH FIRST 1 ROW ONLY),
        (SELECT startDate FROM Employees WHERE departmentID = 3 ORDER BY firstName FETCH FIRST 1 ROW ONLY) 
        + dbms_random.value(0,current_Date-(SELECT startDate FROM Employees WHERE departmentID = 3 ORDER BY firstName FETCH FIRST 1 ROW ONLY)));

INSERT INTO Managers (managerID, employeeNo, departmentID, managerStart) 
VALUES  (MAN_ID_SEQ.NEXTVAL, 
        (SELECT employeeNo FROM Employees WHERE departmentID = 4 ORDER BY firstName FETCH FIRST 1 ROW ONLY),
        (SELECT departmentID FROM Employees WHERE departmentID = 4 ORDER BY firstName FETCH FIRST 1 ROW ONLY),
        (SELECT startDate FROM Employees WHERE departmentID = 4 ORDER BY firstName FETCH FIRST 1 ROW ONLY) 
        + dbms_random.value(0,current_Date-(SELECT startDate FROM Employees WHERE departmentID = 4 ORDER BY firstName FETCH FIRST 1 ROW ONLY)));

INSERT INTO Managers (managerID, employeeNo, departmentID, managerStart) 
VALUES  (MAN_ID_SEQ.NEXTVAL, 
        (SELECT employeeNo FROM Employees WHERE departmentID = 5 ORDER BY firstName FETCH FIRST 1 ROW ONLY),
        (SELECT departmentID FROM Employees WHERE departmentID = 5 ORDER BY firstName FETCH FIRST 1 ROW ONLY),
        (SELECT startDate FROM Employees WHERE departmentID = 5 ORDER BY firstName FETCH FIRST 1 ROW ONLY) 
        + dbms_random.value(0,current_Date-(SELECT startDate FROM Employees WHERE departmentID = 5 ORDER BY firstName FETCH FIRST 1 ROW ONLY)));

-- Updates the manager end date if an employee who is a manager has left and thus their managerial tenure has ended
UPDATE Managers
SET managerEnd = (SELECT endDate FROM Employees WHERE Employees.employeeNo = Managers.employeeNo);

-- Randomly assigns each employee a manager from the employees in the employee table
BEGIN
    assignManager;
END;