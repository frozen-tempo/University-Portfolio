------------------------------------

-- HEP505 DATABASES FINAL ASSIGNMENT - VIEWS DML CODE FOR COMPANY DATABASE
-- BY LUKE GILBERT
-- 22/04/2024

------------------------------------

CREATE or REPLACE VIEW departmentView
AS 
SELECT
    E.firstName || ' ' || E.lastName AS employeeName,
    DPT.departmentName AS departmentName,
    (SELECT firstName FROM Employees WHERE employeeNo = E.reportsTo) || ' ' || (SELECT lastName FROM Employees WHERE employeeNo = E.reportsTo) AS EmployeeManagerName,
    (SELECT firstName FROM Employees WHERE employeeNo = M.employeeNo) || ' ' || (SELECT lastName FROM Employees WHERE employeeNo = M.employeeNo) AS DepartmentManagerName
    FROM departments DPT
        JOIN employees E on DPT.departmentID = E.departmentID
        JOIN managers M on DPT.departmentID = M.departmentID
    ORDER BY employeeName;

CREATE or REPLACE VIEW dependentsView
AS 
SELECT
    E.firstName || ' ' || E.lastName AS employeeName,
    round(months_between(current_date,E.DoB)/12,0) AS employeeAge,
    DEP.firstName || ' ' || DEP.lastName AS dependentName,
    round(months_between(current_date,DEP.DoB)/12,0) AS dependentAge,
    (SELECT relationship FROM Employees WHERE employeeNo = E.employeeNo) AS Relationship
    FROM dependents DEP
        JOIN employees E on DEP.employeeNo = E.employeeNo
    ORDER BY employeeName;

CREATE or REPLACE VIEW inventoryView
AS 
SELECT
    DISTINCT P.productName as ProductName,
    sum(SI.stock) over (partition by ProductName order by ProductName) AS TotalStock
    FROM stockItem SI
        JOIN products P on SI.productID = P.productID
    ORDER BY ProductName;

