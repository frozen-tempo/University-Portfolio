create or replace FUNCTION generatePhoneNumber

RETURN varchar2 AS

    prefix varchar2(3) := '+44';
    phoneNumber varchar2(10):= NULL;
    outputString varchar2(13);

BEGIN

    for refNumLoop in 1..10
    loop
        phoneNumber := concat(to_char(round(DBMS_RANDOM.VALUE(1,9),0)),phoneNumber);
    end loop;

    outputString := prefix || phoneNumber ;

    return outputString;

END generatePhoneNumber;
/