create or replace FUNCTION getRandomAddress

RETURN varchar2 AS

    randomID number;
    temp varchar2(200);
    randomAddress varchar2(200);

BEGIN

    randomID := round(dbms_random.value(241,3000),0);

    SELECT address into temp FROM addresses WHERE ID = randomID;
    randomAddress := temp;

    return randomAddress;

END getRandomAddress;
/