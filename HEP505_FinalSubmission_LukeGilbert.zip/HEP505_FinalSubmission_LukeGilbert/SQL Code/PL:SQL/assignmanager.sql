create or replace PROCEDURE assignManager
IS
    valid BOOLEAN := false;
    temp NUMBER;
    managerDept NUMBER;
    employeeDept NUMBER;
    managerExists NUMBER;
BEGIN
    FOR record_ IN (SELECT * FROM Employees ORDER BY EmployeeNo)
    LOOP
        WHILE valid = false
        LOOP
            temp := round(dbms_random.value(1,100),0);
            SELECT departmentID INTO employeeDept FROM Employees WHERE employeeNo = record_.employeeNo;
            SELECT departmentID INTO managerDept FROM Employees WHERE employeeNo = temp;
            SELECT COUNT(*) INTO managerExists FROM Managers WHERE employeeNo = record_.employeeNo;
            IF (record_.employeeNo <> temp) AND (employeeDept = managerDept) THEN
                UPDATE Employees SET reportsTo = temp WHERE employeeNo = record_.employeeNo;
                valid := true;
                EXIT;
            ELSIF (managerExists = 1) THEN
                valid := true;
                EXIT;
            END IF;
        END LOOP;
        valid := false;
    END LOOP;
END assignManager;
/