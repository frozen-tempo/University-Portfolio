create or replace FUNCTION generateNINumber

RETURN varchar2 AS

    -- function generates a random national insurance number in line with standard format 
    -- https://en.wikipedia.org/wiki/National_Insurance_number#:~:text=The%20format%20of%20the%20number,letter%20also%20cannot%20be%20O.
    prefix varchar2(2);
    referenceNumber varchar2(6):= NULL;
    suffix varchar2(1);
    outputString varchar2(9);

BEGIN

    prefix := concat(substr('ABCEHJKLMNOPRSTWXYZ', DBMS_RANDOM.VALUE(1,20),1), substr('ABCEHJKLMNPRSTWXYZ', DBMS_RANDOM.VALUE(1,20),1));

    for refNumLoop in 1..6
    loop
        referenceNumber := concat(to_char(round(DBMS_RANDOM.VALUE(1,9),0)),referenceNumber);
    end loop;

    suffix := substr('ABCD', DBMS_RANDOM.VALUE(1,4),1);
    
    outputString := prefix || referenceNumber || suffix;

    return outputString;

END generateNINumber;
/