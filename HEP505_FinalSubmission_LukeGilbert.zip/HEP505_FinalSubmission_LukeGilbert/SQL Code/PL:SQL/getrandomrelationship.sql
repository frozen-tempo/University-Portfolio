create or replace FUNCTION getRandomRelationship(employeeDoB DATE, dependentDoB DATE)

RETURN varchar2 AS

    employeeAge NUMBER;
    dependentAge NUMBER;
    relationship varchar2(9);

BEGIN

    employeeAge := months_between(sysdate,employeeDoB)/12;
    dependentAge := months_between(sysdate,dependentDoB)/12;

    IF (employeeAge > dependentAge AND employeeAge - dependentAge > 18) OR (dependentAge < 18) THEN
            relationship := CASE round(dbms_random.value(1,2),0)
                            WHEN 1 THEN 'Child'
                            ELSE 'Other'
                            END;
    ELSIF dependentAge > (employeeAge + 18) THEN
            relationship := CASE round(dbms_random.value(1,2),0)
                            WHEN 1 THEN 'Parent'
                            ELSE 'Other'
                            END;
    ELSIF dependentAge > 18 THEN
            relationship := CASE round(dbms_random.value(1,2),0)
                            WHEN 1 THEN 'Spouse'
                            ELSE 'Other'
                            END;

    END IF;

    return relationship;

END;
/