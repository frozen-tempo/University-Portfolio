"""

This program looks to analyse the Fantasy Premier League data set for the first 7 gameweeks of the season.
Data from https://github.com/vaastav/Fantasy-Premier-League/tree/master
The program looks to identify salient data points and trends within the dataset 
to provide users with useful information about team selection and transfer decisions.

----------------------------------------------------------------------------------------------------------

Main columns of interest in analysis (0 indexed):

Column 0 : playerNames -> Data for player names.

Column 1 : playerPosition -> Data for player's position as allocated by FPL.

Column 3 : xP -> Data for a player's expected points based on a number of factors such as fixture difficulty,
player form, injury status, etc.

Column 20: minutes -> Data for a player's gametime for a given week (in order to not skew the data, removal of
players with 0 minutes in a given gameweek are filtered out for analysis).

Column 33: points -> Data for a player's actual points scored for that week based on the offical FPL scoring
system.

Column 37 : playerPrice -> Data for player's price as determined by FPL, note that depending on the transfers
in and out of FPL managers teams this price may rise or fall.

Column 38 : wasHome -> Data for if the player was playing at home on a given game week.

Column 40 : gameWeek -> Data displaying the current gameweek for the data row.

"""

import pandas as pd


# Function for counting number of rows of data in dataset
def countDataRows(data):
    numDataRows = 0
    for row in data:
        numDataRows += 1
    return (
        numDataRows - 1
    )  # Returns number of rows in dataset minus the row with headers for the columns


# Function for formatting the csv into a 2D array
def formatCSV(data):
    formattedData = []
    for row in fplData:
        formattedData.append((row.split(",")))
    return formattedData


# Get a column of data and return it as an array
# We only want to count players that have actually played in the games that week as otherwise the data would be skewed
def getDataColumn(data, columnNo):
    playerNames = []
    dataArray = []
    for row in data[1:]:
        minutes = int(row[20])  # Minutes Column
        if minutes > 0:
            dataArray.append(float(row[columnNo]))
            playerNames.append(
                row[0] + ", Week " + row[40]
            )  # For plotting use player name and game week as idenifier for data points
    return dataArray, playerNames


# Function for applying price adjustment to player points
def applyAdjustment(datsetA, datasetB):
    adjustedData = []
    for points, price in zip(datsetA, datasetB):
        adjustedData.append(round((points / price), 3))
    return adjustedData


# Function to compute the average number of points of players playing at home vs. playing away
def homeVsAway(data):
    homeTotal = 0
    homeCount = 0
    awayTotal = 0
    awayCount = 0
    for row in data[1:]:  # Start from second row as the dataset contains a header row
        homeGame = row[38]
        minutes = int(row[20])
        points = int(row[33])
        if homeGame == "True" and minutes > 0:
            homeTotal += points
            homeCount += 1
        elif homeGame == "False" and minutes > 0:
            awayTotal += points
            awayCount += 1
    return round(homeTotal / homeCount, 3), round(awayTotal / awayCount, 3)


# Function to compute the average points of players for a given position and price range
def getAvgPointsByPositionAndPriceRange(data, position, lowPrice, highPrice):
    total = 0
    count = 0
    for row in data[1:]:  # Start from second row as the dataset contains a header row
        playerPos = row[1]
        points = int(row[33])
        price = int(row[37])
        if (
            playerPos == position and lowPrice < price < highPrice
        ):  # Checks the position of a given entry vs. filter criteria, prices are given as integers from 40 to 140
            total += points
            count += 1
        if total == 0 or count == 0:
            average = 0
        else:
            average = total / count

    return round(average, 3)


# Function to determines the maximum for an array of data and returns that maximum
def getMax(data):
    max = 0
    for row in data[1:]:  # Start from second row as the dataset contains a header row
        point = int(row)
        if point > max:
            max = point
    return max


# Function to determines the minimum for an array of data and returns that minimum
def getMin(data):
    min = 0
    for row in data[1:]:  # Start from second row as the dataset contains a header row
        point = int(row)
        if point < min:
            min = point
    return min


# Initial Load, Reading of Lines in File and Formatting of CSV Data.
dataFile = "merged_gw.csv"
fplData = open(dataFile, "r").readlines()
formattedCSV = formatCSV(fplData)

# Get Column Data for Analysis
points = getDataColumn(formattedCSV, 33)[0]
playerPrice = getDataColumn(formattedCSV, 37)[0]


# Pandas Validation Code
def validateOutput(testCase, programOutput, pandasOutput):
    status = "Not Verified"
    if programOutput == pandasOutput:
        status = "Verified"
    print(testCase + ": " + status)


# Initialise all expected test output using pandas
dataFilePandas = pd.read_csv(dataFile)
datasetLengthPandas = len(dataFilePandas)
datasetMaxPointsPandas = dataFilePandas["total_points"].max()
datasetMinPointsPandas = dataFilePandas["total_points"].min()
datasetHomeAvgPandas = round(
    (dataFilePandas.query("was_home == True & minutes > 0")["total_points"].mean()),
    3,
)
datasetAwayAvgPandas = round(
    (dataFilePandas.query("was_home == False & minutes > 0")["total_points"].mean()),
    3,
)
datasetPosAndPriceAvgPandas = round(
    (
        dataFilePandas.query("position == 'MID' & 40 < value < 100")[
            "total_points"
        ].mean()
    ),
    3,
)
# Array of test cases with test case name, actual ouput and expected output
testCases = [
    ["Data File Length", str(countDataRows(fplData)), str(datasetLengthPandas)],
    ["Max Points", str(getMax(points)), str(datasetMaxPointsPandas)],
    ["Min Points", str(getMin(points)), str(datasetMinPointsPandas)],
    ["Home Average", str(homeVsAway(formattedCSV)[0]), str(datasetHomeAvgPandas)],
    ["Away Average", str(homeVsAway(formattedCSV)[1]), str(datasetAwayAvgPandas)],
    [
        "Average Position and Price Filter",
        str(getAvgPointsByPositionAndPriceRange(formattedCSV, "MID", 40, 100)),
        str(datasetPosAndPriceAvgPandas),
    ],
]
print("Verifying Dataset and Operations...")
for testCase in testCases:
    validateOutput(testCase[0], testCase[1], testCase[2])


# User Input Validation and Error Handling
def inputPositionAndPrice():
    validPositions = ["GK", "DEF", "MID", "FWD"]
    position = ""
    while position not in validPositions:
        position = input(
            "Please enter a player position(Choose from: GK, DEF, MID, FWD):"
        )
    validPriceRange = False
    while validPriceRange == False or lowPrice < 0 or highPrice < 0:
        lowPrice = int(
            input(
                "Please entered a lower price limit (Prices range typically between: 40 and 140):"
            )
        )
        highPrice = int(
            input(
                "Please entered a higher price limit (Prices range typically between: 40 and 140):"
            )
        )
        if lowPrice >= highPrice or lowPrice < 0 or highPrice < 0:
            print("The price range you have entered is invalid, Please try again.")
        else:
            validPriceRange = True
    return position, lowPrice, highPrice


def userMenu():
    endProgram = False
    while endProgram != True:
        analysisChoice = input(
            """
Welcome to the data analysis programe for FPL Data. This program comprises of data from the first 7 gameweeks of the Premier League Season.

Please select an option from below to begin:

1. View the total number of records in the dataset.
2. Calculate Player Points Adjusted by Player Price.
3. Calculate Average Player Points at Home vs. Away
4. Calculate Average Player Points for a Position within a Price Range
5. Calculate Maximum Player Points in Dataset
6. Calculate Minimum Player Points in Dataset
7. Exit Program

Enter your choice:"""
        )
        if analysisChoice == "1":
            print("Number of Records in Dataset: " + str(countDataRows(fplData)))
        elif analysisChoice == "2":
            print(applyAdjustment(points, playerPrice))
        elif analysisChoice == "3":
            print("Average Home Score: " + str(homeVsAway(formattedCSV)[0]))
            print("Average Away Score: " + str(homeVsAway(formattedCSV)[1]))
        elif analysisChoice == "4":
            filterData = inputPositionAndPrice()
            position = filterData[0]
            lowPrice = filterData[1]
            highPrice = filterData[2]
            print(
                "The average number of points for a "
                + position
                + " between the price range of "
                + str(lowPrice)
                + " and "
                + str(highPrice)
                + " is: %4.2f"
                % (
                    getAvgPointsByPositionAndPriceRange(
                        formattedCSV, position, lowPrice, highPrice
                    )
                )
            )
        elif analysisChoice == "5":
            print("Max Points: " + str(getMax(points)))
        elif analysisChoice == "6":
            print("Min Points: " + str(getMin(points)))
        elif analysisChoice == "7":
            endProgram = True
        else:
            print(
                "You have entered invalid option, please look at the list below and try again."
            )


userMenu()
