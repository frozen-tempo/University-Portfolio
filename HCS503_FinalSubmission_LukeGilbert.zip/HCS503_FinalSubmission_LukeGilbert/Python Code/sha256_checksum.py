import hashlib

def sha256_hash(str):
    return hashlib.sha256(str.encode()).hexdigest()
