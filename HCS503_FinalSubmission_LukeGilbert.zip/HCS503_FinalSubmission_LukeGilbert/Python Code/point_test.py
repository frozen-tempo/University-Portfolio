''' 
Point Class Test
Luke Gilbert
HCS503 Data Structures and Algorithms
05/08/24
'''

import unittest
from point import Point

class TestPoint(unittest.TestCase):
    def setUp(self):
        self.test_point = Point(5,5)

    def test_get_distance(self):
        test_neighbour = Point(2,2)
        expected_result = 4.243
        self.assertEqual(expected_result,round(self.test_point.get_distance(test_neighbour),3))

    def test_get_neighbours(self):
        proximity = 5
        test_point_list = []
        for x,y in zip(range(1,20),range(1,20)):
            test_point_list.append(Point(x,y))
        expected_result = [Point(2,2),Point(3,3),Point(4,4),Point(5,5),Point(6,6),Point(7,7),Point(8,8)]
        self.assertEqual(expected_result,self.test_point.get_neighbours(test_point_list,proximity))