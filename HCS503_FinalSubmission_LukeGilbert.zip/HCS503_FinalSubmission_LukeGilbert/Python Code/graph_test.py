''' 
Graph Class Test Code
Luke Gilbert
HCS503 Data Structures and Algorithms
05/08/24
'''

import unittest
from graph import Graph
from point import Point

class TestGraph(unittest.TestCase):
    
    def setUp(self):
        self.proximity = 5
        self.test_point_list = []
        for x,y in zip(range(1,5),range(1,5)):
            self.test_point_list.append(Point(x,y))
        self.graph_dict = {}
        for point in self.test_point_list:
            self.graph_dict[point] = point.get_neighbours(self.test_point_list,self.proximity)
        self.graph = Graph(self.graph_dict)
        self.maxDiff = None
    
    def test_add_node(self):
        self.graph.add_node(Point(1,5))
        expected_result = [Point(1,1), Point(2,2), Point(3,3), Point(4,4), Point(1,5)]
        self.assertEqual(expected_result,self.graph.nodes)

    def test_add_edge(self):
        self.graph.add_node(Point(1,5))
        self.graph.generate_edges()
        self.graph.add_edge(Point(1,1), Point(1,5), Point(1,1).get_distance(Point(1,5)))
        expected_result = [{"node": Point(1,1), "neighbour": Point(2,2), "weight":1.4142135623730951},
                            {"node": Point(1,1), "neighbour": Point(3,3), "weight":2.8284271247461903},
                            {"node": Point(1,1), "neighbour": Point(4,4), "weight":4.242640687119285},
                            {"node": Point(2,2), "neighbour": Point(1,1), "weight":1.4142135623730951},
                            {"node": Point(2,2), "neighbour": Point(3,3), "weight":1.4142135623730951},
                            {"node": Point(2,2), "neighbour": Point(4,4), "weight":2.8284271247461903},
                            {"node": Point(3,3), "neighbour": Point(1,1), "weight":2.8284271247461903},
                            {"node": Point(3,3), "neighbour": Point(2,2), "weight":1.4142135623730951},
                            {"node": Point(3,3), "neighbour": Point(4,4), "weight":1.4142135623730951},
                            {"node": Point(4,4), "neighbour": Point(1,1), "weight":4.242640687119285},
                            {"node": Point(4,4), "neighbour": Point(2,2), "weight":2.8284271247461903},
                            {"node": Point(4,4), "neighbour": Point(3,3), "weight":1.4142135623730951},
                            {"node": Point(1,1), "neighbour": Point(1,5), "weight":4.0},
                            {"node": Point(1,5), "neighbour": Point(1,1), "weight":4.0}]
        self.assertEqual(expected_result, self.graph.edges)

    def test_generate_edges(self):
        self.graph.generate_edges()
        expected_result = [{"node": Point(1,1), "neighbour": Point(2,2), "weight":1.4142135623730951},
                            {"node": Point(1,1), "neighbour": Point(3,3), "weight":2.8284271247461903},
                            {"node": Point(1,1), "neighbour": Point(4,4), "weight":4.242640687119285},
                            {"node": Point(2,2), "neighbour": Point(1,1), "weight":1.4142135623730951},
                            {"node": Point(2,2), "neighbour": Point(3,3), "weight":1.4142135623730951},
                            {"node": Point(2,2), "neighbour": Point(4,4), "weight":2.8284271247461903},
                            {"node": Point(3,3), "neighbour": Point(1,1), "weight":2.8284271247461903},
                            {"node": Point(3,3), "neighbour": Point(2,2), "weight":1.4142135623730951},
                            {"node": Point(3,3), "neighbour": Point(4,4), "weight":1.4142135623730951},
                            {"node": Point(4,4), "neighbour": Point(1,1), "weight":4.242640687119285},
                            {"node": Point(4,4), "neighbour": Point(2,2), "weight":2.8284271247461903},
                            {"node": Point(4,4), "neighbour": Point(3,3), "weight":1.4142135623730951}
                            ]
        self.assertEqual(expected_result,self.graph.edges)

