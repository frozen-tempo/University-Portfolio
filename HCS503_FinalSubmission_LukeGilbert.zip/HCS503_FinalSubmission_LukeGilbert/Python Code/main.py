''' 
Driver Code (Main)
Luke Gilbert
HCS503 Data Structures and Algorithms
05/08/24
'''

from graph import Graph
from point import Point
from prims import prims_mst
import matplotlib.pyplot as plt
import networkx as nx
from y_values import y_list
from sha256_checksum import sha256_hash

# Validates the list of provided Y values using SHA256 hashing algorithm provided an expected hash string
y_str = ""
validated = False
for y in y_list:
    y_str += str(y)

if sha256_hash(y_str) == "5c14e4599f1d2a39abe6b487ac2a5415c894c6882f5fdd4a40e02c7dd628829a":
    validated = True

if validated:
    # Generate a list of points from the provided Y values and X values from 1 to 100
    point_list =[]
    proximity = 20
    for x,y in zip(range(1,101),y_list):
        point_list.append(Point(x, y))

    # Generate a graph dictionary entry for all nodes with edges to neighbours within a given proximity
    graph_dict = {}
    for point in point_list:
        graph_dict[point] = point.get_neighbours(point_list,proximity)

    # Creates instance of Graph object
    graph = Graph(graph_dict)

    # Calls function for calculating MST using Prim's algorithm and stores results as two variables
    total_mst_cost, mst_edges = prims_mst(graph.nodes, graph.generate_edges())

    # Uses the NetworkX and Matplotlib libraries in python to visualise the graph notes and the minimum spanning tree edges
    G = nx.Graph()
    for point in point_list:
        G.add_node(point, pos=(point.get_x(), point.get_y()))
    pos = nx.get_node_attributes(G,'pos')
    for edge in mst_edges[1:]:
        G.add_edge(edge[1], edge[0])
    nx.draw(G,pos, node_size=25)
    plt.show()