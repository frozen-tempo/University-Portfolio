''' 
Prims MST Algorithm
Luke Gilbert
HCS503 Data Structures and Algorithms
05/08/24
'''

# Get minimium cost spanning tree using Prim's Algorithm 
# (https://en.wikipedia.org/wiki/Prim%27s_algorithm#:~:text=In%20computer%20science%2C%20Prim's%20algorithm,in%20the%20tree%20is%20minimized.)
import heapq

def prims_mst(nodes, edges):

    if not nodes or not edges:
        return None

    n = len(nodes)
    mst_edges = []

    adjacency = {node:[] for node in nodes}
    for edge in edges:
        adjacency[edge["node"]].append([edge["weight"], edge["neighbour"]])
        adjacency[edge["neighbour"]].append([edge["weight"], edge["node"]])

    total_mst_cost = 0
    visited = set()
    min_heap = [[0, nodes[0], nodes[0]]]
    while len(visited) < n:
        weight, node, neighbour = heapq.heappop(min_heap)
        if node in visited:
            continue
        total_mst_cost += weight
        mst_edges.append([neighbour, node, weight])
        visited.add(node)
        for neighbour_weight, neighbour in adjacency[node]:
            heapq.heappush(min_heap, [neighbour_weight,neighbour, node])

    return total_mst_cost, mst_edges