''' 
Graph Class
Luke Gilbert
HCS503 Data Structures and Algorithms
05/08/24
'''

class Graph:

    def __init__(self, graph):
        self.graph = graph
        self.nodes = []
        self.edges = []
        for node in self.graph.keys():
            self.nodes.append(node)

    def __str__(self):
        graph_str = {}
        for node,neighbours in self.graph:
            graph_str[str(node)] = [str(neighbour) for neighbour in neighbours]
        return str(graph_str)
    
    def get_nodes(self):
        return self.nodes
    
    def get_edges(self):
        return self.edges
    
    def add_node(self, node):
        if node not in self.nodes:
            self.nodes.append(node)

    def add_edge(self, start_node, end_node, weight):
        valid_nodes = start_node and end_node in self.nodes
        if start_node != end_node and valid_nodes :
            self.edges.append({"node":start_node,"neighbour":end_node,"weight":weight})
            self.edges.append({"node":end_node,"neighbour":start_node,"weight":weight})
    
    def generate_edges(self):
        for node in self.graph:
            for neighbour in self.graph[node]:
                if node != neighbour:
                    self.edges.append({"node": node, 
                                "neighbour": neighbour, 
                                "weight": node.get_distance(neighbour)})
        return self.edges
    
    def __iter__(self):
        self.__iter = iter(self.graph)
        return self.__iter

