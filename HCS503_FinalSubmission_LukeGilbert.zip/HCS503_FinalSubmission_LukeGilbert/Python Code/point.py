''' 
Point Class
Luke Gilbert
HCS503 Data Structures and Algorithms
05/08/24
'''

import math
import functools

@functools.total_ordering
class Point:
    # Initialises the point object with an x and y coordinate
    def __init__(self, x:int, y:int):
        self.x = x
        self.y = y

    def __lt__(self, other):
        return self.x < other.x
    
    def __gt__(self, other):
        return self.x > other.x
    
    def __eq__(self, other):
        if isinstance(self, other.__class__):
            return self.__key() == other.__key()
        return False
    
    def __key(self):
        return (self.x, self.y)
    
    def __hash__(self):
        return hash(self.__key())
    
    # Gets the distance from the point to another selected point by the user
    def get_distance(self, point):
        return math.sqrt(((point.get_x() - self.x)**2)+((point.get_y() - self.y)**2))
    
    # Returns x coordinate for the point
    def get_x(self):
        return self.x
    
    # Returns y coordinate for the point
    def get_y(self):
        return self.y
    
    # Returns a list of neighbours for a given point
    def get_neighbours(self, point_list, proximity):
        neighbours = []
        for p in point_list:
            if self.get_distance(p) <= proximity:
                neighbours.append(p)
        return neighbours
    
    # Prints a points given x and y coordinate
    def __str__(self):
        return f'X: {self.x}, Y: {self.y}'
    