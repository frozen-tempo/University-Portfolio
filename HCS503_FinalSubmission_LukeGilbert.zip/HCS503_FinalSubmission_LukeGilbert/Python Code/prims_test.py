''' 
Prims MST Algorithm Test Code
Luke Gilbert
HCS503 Data Structures and Algorithms
05/08/24
'''

import unittest
from prims import prims_mst

class TestPrimsMST(unittest.TestCase):
    
    def test_simple_graph(self):
        nodes = ["A", "B", "C", "D", "E"]
        edges = [{"node": "A", "weight": 5, "neighbour": "B"},
                {"node": "A", "weight": 2, "neighbour": "C"},
                {"node": "A", "weight": 1, "neighbour": "D"},
                {"node": "B", "weight": 10, "neighbour": "C"},
                {"node": "B", "weight": 4, "neighbour": "D"},
                {"node": "C", "weight": 13, "neighbour": "D"},
                {"node": "B", "weight": 40, "neighbour": "E"},
                {"node": "C", "weight": 34, "neighbour": "E"},
                {"node": "A", "weight": 14, "neighbour": "E"}]
        expected_result = 21, [["A","A",0], ["A","D",1], ["A","C",2], ["D","B",4], ["A","E",14]]
        self.assertEqual(expected_result, prims_mst(nodes,edges))

    def test_negative_edges(self):
        nodes = ["A", "B", "C", "D", "E"]
        edges = [{"node": "A", "weight": -2, "neighbour": "B"},
                {"node": "A", "weight": 2, "neighbour": "C"},
                {"node": "A", "weight": 1, "neighbour": "D"},
                {"node": "B", "weight": -10, "neighbour": "C"},
                {"node": "B", "weight": 4, "neighbour": "D"},
                {"node": "C", "weight": 13, "neighbour": "D"},
                {"node": "B", "weight": 40, "neighbour": "E"},
                {"node": "C", "weight": -4, "neighbour": "E"},
                {"node": "A", "weight": 14, "neighbour": "E"}]
        expected_result = -15, [["A","A",0], ["A","B",-2], ["B","C",-10], ["C","E",-4], ["A","D",1]]
        self.assertEqual(expected_result, prims_mst(nodes,edges))

    def test_empty_nodes(self):
        nodes = []
        edges = [{"node": "A", "weight": 5, "neighbour": "B"},
                {"node": "A", "weight": 2, "neighbour": "C"}]
        expected_result = None
        self.assertEqual(expected_result, prims_mst(nodes, edges))

    def test_empty_edges(self):
        nodes = ["A", "B", "C", "D", "E"]
        edges = []
        expected_result = None
        self.assertEqual(expected_result, prims_mst(nodes, edges))

    